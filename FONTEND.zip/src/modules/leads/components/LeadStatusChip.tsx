import Chip from "@mui/material/Chip";
import type { LeadResponse } from "@/api/generated";

interface Props {
  status?: LeadResponse["status"];
}

export function LeadStatusChip({ status }: Props) {
  const label = String(status ?? "UNKNOWN");
  const color =
    status === "WON" ? "success" : status === "LOST" ? "error" : "default";

  return <Chip label={label} color={color as any} size="small" />;
}
