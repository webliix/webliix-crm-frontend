import { AppDataTable } from "@/shared/components/ui/table";
import { createLeadColumns } from "./leadColumns";
import type { LeadResponse } from "@/api/generated";

interface Props {
  leads: LeadResponse[];
  total: number;
  page: number;
  pageSize: number;
  onPageChange?: (page: number) => void;
  onPageSizeChange?: (size: number) => void;
  onView?: (id: number) => void;
  onEdit?: (id: number) => void;
  onDelete?: (id: number) => void;
  onConvert?: (id: number) => void;
}

export function LeadTable({ leads, total, page, pageSize, onPageChange, onPageSizeChange, onView, onEdit, onDelete, onConvert }: Props) {
  const columns = createLeadColumns({ onView, onEdit, onDelete, onConvert });
  return (
    <AppDataTable
      rows={leads}
      columns={columns}
      loading={false}
      page={page}
      pageSize={pageSize}
      totalRows={total}
      onPageChange={onPageChange}
      onPageSizeChange={onPageSizeChange}
    />
  );
}
