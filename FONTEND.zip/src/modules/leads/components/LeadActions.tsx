import Stack from "@mui/material/Stack";
import { AppButton } from "@/shared/components/ui";
import { ActionGuard } from "@/shared/components/rbac/ActionGuard";
import { permissions } from "@/shared/rbac/permissions";
import type { LeadResponse } from "@/api/generated";
import { useNavigate } from "react-router-dom";
import { useDeleteLead } from "@/modules/leads/hooks/useDeleteLead";
import { useConvertLead } from "@/modules/leads/hooks/useConvertLead";

interface Props {
  lead: LeadResponse;
  onView?: (id: number) => void;
  onEdit?: (id: number) => void;
  onDelete?: (id: number) => void;
  onConvert?: (id: number) => void;
}

export function LeadActions({ lead, onView, onEdit, onDelete, onConvert }: Props) {
  const navigate = useNavigate();
  const deleteMutation = useDeleteLead();
  const convertMutation = useConvertLead();

  const handleView = () => {
    if (onView) return onView(lead.id as number);
    navigate(`/leads/${lead.id}`);
  };

  const handleEdit = () => {
    if (onEdit) return onEdit(lead.id as number);
    navigate(`/leads/${lead.id}/edit`);
  };

  const handleDelete = () => {
    if (onDelete) return onDelete(lead.id as number);
    deleteMutation.mutate(lead.id as number);
  };

  const handleConvert = () => {
    if (onConvert) return onConvert(lead.id as number);
    convertMutation.mutate(lead.id as number);
  };

  return (
    <Stack direction="row" spacing={1} flexWrap="wrap">
      <AppButton size="small" onClick={handleView}>
        View
      </AppButton>
      <ActionGuard permission={permissions.leads.edit}>
        <AppButton size="small" onClick={handleEdit}>
          Edit
        </AppButton>
      </ActionGuard>
      <ActionGuard permission={permissions.leads.delete}>
        <AppButton size="small" color="error" onClick={handleDelete}>
          Delete
        </AppButton>
      </ActionGuard>
      <ActionGuard permission={permissions.leads.convert}>
        <AppButton size="small" onClick={handleConvert}>
          Convert
        </AppButton>
      </ActionGuard>
    </Stack>
  );
}
