import Drawer from "@mui/material/Drawer";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import { AppCard } from "@/shared/components/ui";
import { useLead } from "@/modules/leads/hooks/useLead";
import type { LeadResponse } from "@/api/generated";

interface Props {
  id?: number | null;
  open: boolean;
  onClose: () => void;
}

export function LeadDetailsDrawer({ id, open, onClose }: Props) {
  const { data, isLoading } = useLead(id ?? 0);
  const lead: LeadResponse | undefined = data?.data;

  return (
    <Drawer anchor="right" open={open} onClose={onClose} PaperProps={{ sx: { width: 480 } }}>
      <Box sx={{ p: 2 }}>
        <AppCard>
          {isLoading ? (
            <Typography>Loading...</Typography>
          ) : !lead ? (
            <Typography>No lead</Typography>
          ) : (
            <Box>
              <Typography variant="h6">{lead.companyName}</Typography>
              <Typography>{lead.contactPerson}</Typography>
              <Typography>{lead.phone}</Typography>
              <Typography>{lead.email}</Typography>
              <Typography>{lead.address}</Typography>
              <Typography>{lead.city}, {lead.state}, {lead.country}</Typography>
              <Typography>{lead.requirements}</Typography>
              <Typography>Value: {lead.estimatedValue}</Typography>
            </Box>
          )}
        </AppCard>
      </Box>
    </Drawer>
  );
}
