import Typography from "@mui/material/Typography";
import { AppCard, AppTextField } from "@/shared/components/ui";
import { useEffect, useState } from "react";

interface Props {
  onSearch?: (value: string) => void;
}

export function LeadFilters({ onSearch }: Props) {
  const [value, setValue] = useState("");

  useEffect(() => {
    const t = setTimeout(() => {
      onSearch?.(value);
    }, 500);

    return () => clearTimeout(t);
  }, [value, onSearch]);

  return (
    <AppCard>
      <Typography variant="subtitle1">Search</Typography>
      <AppTextField placeholder="Search leads..." onChange={(e: any) => setValue(e.target.value)} />
      <Typography variant="body2" color="text.secondary">
        Status
      </Typography>
    </AppCard>
  );
}
