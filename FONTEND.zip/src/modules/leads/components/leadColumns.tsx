import type { DataTableColumn } from "@/shared/components/ui/table";
import type { LeadResponse } from "@/api/generated";
import { LeadStatusChip } from "./LeadStatusChip";
import { LeadActions } from "./LeadActions";

export function createLeadColumns(handlers?: {
  onView?: (id: number) => void;
  onEdit?: (id: number) => void;
  onDelete?: (id: number) => void;
  onConvert?: (id: number) => void;
}): DataTableColumn<LeadResponse>[] {
  return [
    { field: "companyName" as keyof LeadResponse, headerName: "Company", flex: 1 },
    { field: "contactPerson" as keyof LeadResponse, headerName: "Contact", flex: 1 },
    { field: "phone" as keyof LeadResponse, headerName: "Phone", flex: 1 },
    { field: "email" as keyof LeadResponse, headerName: "Email", flex: 1 },
    {
      field: "status" as keyof LeadResponse,
      headerName: "Status",
      flex: 1,
      render: (_value, row) => <LeadStatusChip status={row.status} />,
    },
    {
      field: "source" as keyof LeadResponse,
      headerName: "Source",
      flex: 1,
    },
    {
      field: "estimatedValue" as keyof LeadResponse,
      headerName: "Estimated Value",
      flex: 1,
    },
    { field: "createdAt" as keyof LeadResponse, headerName: "Created", flex: 1 },
    {
      field: "id" as keyof LeadResponse,
      headerName: "Actions",
      flex: 1,
      render: (_value, row) => (
        <LeadActions
          lead={row}
          onView={handlers?.onView}
          onEdit={handlers?.onEdit}
          onDelete={handlers?.onDelete}
          onConvert={handlers?.onConvert}
        />
      ),
    },
  ];
}
