import { useNavigate } from "react-router-dom";
import Typography from "@mui/material/Typography";
import { AppCard } from "@/shared/components/ui";
import {
  AppForm,
  AppTextField,
  AppSelectField,
  AppCurrencyField,
  AppTextAreaField,
  AppDateField,
  FormSection,
} from "@/shared/components/form";
import { useCreateLead } from "@/modules/leads/hooks/useCreateLead";
import { leadSourceOptions } from "@/modules/leads/constants/lead-source";
import { enumToLabel } from "@/shared/utils/enumMapper";
import type { SelectOption } from "@/shared/types/select-option";
import { notificationService } from "@/shared/notifications/notification.service";

export function LeadForm() {
  const navigate = useNavigate();
  const create = useCreateLead();

  const sourceOptions: SelectOption[] = leadSourceOptions.map((v) => ({
    value: v,
    label: enumToLabel(v),
  }));

  const handleSubmit = async (values: any) => {
    try {
      // construct payload matching CreateLeadRequest
      const payload: any = {
        companyName: values.companyName,
        contactPerson: values.contactPerson,
        email: values.email,
        phone: values.phone,
        requirements: values.requirements,
        estimatedValue: values.estimatedValue ? Number(values.estimatedValue) : undefined,
        source: values.source,
      };

      await create.mutateAsync(payload);
      notificationService.success("Lead created");
      navigate("/leads");
    } catch (err) {
      notificationService.error("Unable to create lead");
    }
  };

  return (
    <AppCard>
      <Typography variant="h6">Create Lead</Typography>

      <AppForm onSubmit={handleSubmit} submitLabel="Create Lead">
        <FormSection title="Lead Information">
          <AppTextField name="companyName" label="Company Name" />
          <AppTextField name="contactPerson" label="Contact Person" />
          <AppTextField name="email" label="Email" />
          <AppTextField name="phone" label="Phone" />
          <AppSelectField name="source" label="Source" options={sourceOptions} />
          <AppCurrencyField name="estimatedValue" label="Estimated Value" currency="INR" />
          <AppTextAreaField name="requirements" label="Requirements" />
          <AppDateField name="nextFollowUpDate" label="Follow-Up Date" />
        </FormSection>
      </AppForm>
    </AppCard>
  );
}
