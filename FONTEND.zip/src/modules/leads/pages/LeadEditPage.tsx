import { AppContainer, PageHeader } from "@/shared/components/ui";
import { LeadForm } from "@/modules/leads/components/LeadForm";

export default function LeadEditPage() {
  return (
    <AppContainer>
      <PageHeader title="Edit Lead" />
      <LeadForm />
    </AppContainer>
  );
}
