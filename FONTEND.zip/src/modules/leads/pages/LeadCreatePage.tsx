import { AppContainer, PageHeader } from "@/shared/components/ui";
import { LeadForm } from "@/modules/leads/components/LeadForm";

export default function LeadCreatePage() {
  return (
    <AppContainer>
      <PageHeader title="Create Lead" />
      <LeadForm />
    </AppContainer>
  );
}
