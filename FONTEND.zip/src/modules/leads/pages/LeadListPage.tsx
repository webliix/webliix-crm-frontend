import { Box } from "@mui/material";
import { AppContainer, PageHeader, AppButton } from "@/shared/components/ui";
import { LeadFilters } from "@/modules/leads/components/LeadFilters";
import { LeadTable } from "@/modules/leads/components/LeadTable";
import { useLeads } from "@/modules/leads/hooks/useLeads";
import { LoadingScreen, EmptyState } from "@/shared/components/ui";
import { useState } from "react";
import { LeadDetailsDrawer } from "@/modules/leads/components/LeadDetailsDrawer";
import { useNavigate } from "react-router-dom";
import { ActionGuard } from "@/shared/components/rbac/ActionGuard";
import { permissions } from "@/shared/rbac/permissions";

export default function LeadListPage() {
  const { rows, total, page, size, setPage, setSize, setSearch, isLoading, isError } = useLeads();
  const leads = rows ?? [];
  const [selectedId, setSelectedId] = useState<number | null>(null);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const navigate = useNavigate();

  const handleView = (id: number) => {
    setSelectedId(id);
    setDrawerOpen(true);
  };

  const handleClose = () => {
    setSelectedId(null);
    setDrawerOpen(false);
  };

  return (
    <AppContainer>
      <Box sx={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <PageHeader title="Leads" />
        <ActionGuard permission={permissions.leads.create}>
          <AppButton onClick={() => navigate("/leads/create")}>Create Lead</AppButton>
        </ActionGuard>
      </Box>
      <Box sx={{ my: 2, display: "grid", gap: 2 }}>
        <LeadFilters onSearch={setSearch} />
        {isLoading ? (
          <LoadingScreen />
        ) : isError ? (
          <EmptyState message="Unable to load leads" />
        ) : (
          <LeadTable
            leads={leads}
            total={total}
            page={page}
            pageSize={size}
            onPageChange={(p) => setPage(p)}
            onPageSizeChange={(s) => setSize(s)}
            onView={handleView}
          />
        )}
      </Box>

      <LeadDetailsDrawer id={selectedId ?? undefined} open={drawerOpen} onClose={handleClose} />
    </AppContainer>
  );
}
