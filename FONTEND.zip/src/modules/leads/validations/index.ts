export * from "./lead.schema";
