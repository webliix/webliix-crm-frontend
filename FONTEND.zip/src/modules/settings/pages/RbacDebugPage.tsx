import { AppContainer, PageHeader } from "@/shared/components/ui";
import { useAppSelector } from "@/app/store/redux";
import { selectUser } from "@/modules/auth/store/selectors";
import { usePermission } from "@/shared/rbac/hooks/usePermission";
import { useRole } from "@/shared/rbac/hooks/useRole";
import { Box, Typography } from "@mui/material";

export default function RbacDebugPage() {
  const user = useAppSelector(selectUser);
  const { permissions } = usePermission();
  const { roles } = useRole();

  return (
    <AppContainer>
      <PageHeader title="RBAC Debug" />
      <Box sx={{ display: "grid", gap: 2 }}>
        <Box>
          <Typography variant="h6">Current User</Typography>
          <Typography>{user ? `${user.firstName} ${user.lastName}` : "No user"}</Typography>
          <Typography>{user?.email}</Typography>
        </Box>

        <Box>
          <Typography variant="h6">Current Roles</Typography>
          <Typography>{roles.length ? roles.join(", ") : "None"}</Typography>
        </Box>

        <Box>
          <Typography variant="h6">Current Permissions</Typography>
          <Typography>{permissions.length ? permissions.join(", ") : "None"}</Typography>
        </Box>
      </Box>
    </AppContainer>
  );
}
