import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { loginSchema, type LoginFormData } from "@/modules/auth/validations/login.schema";
import { AppButton, AppCard, AppTextField, PageHeader } from "@/shared/components/ui";
import { useLogin } from "@/modules/auth/hooks/useLogin";
import { tokens } from "@/theme/tokens";

export default function LoginPage() {
  const { register, handleSubmit, formState } = useForm<LoginFormData>({
    resolver: zodResolver(loginSchema),
  });

  const { mutate, status } = useLogin();
  const isLoading = status === "pending";

  const onSubmit = (data: LoginFormData) => {
    mutate(data);
  };

  return (
    <div
      style={{
        minHeight: "100vh",
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        padding: tokens.spacing.lg,
      }}
    >
      <div style={{ width: 400 }}>
        <AppCard>
          <div
            style={{
              textAlign: "center",
              marginBottom: tokens.spacing.md,
            }}
          >
            <div style={{ fontSize: 32, fontWeight: 700 }}>W</div>
            <PageHeader title="Webliix CRM" />
          </div>

          <form onSubmit={handleSubmit(onSubmit)} noValidate>
            <div style={{ marginBottom: tokens.spacing.md }}>
              <AppTextField
                label="Email"
                type="email"
                {...register("email")}
                error={!!formState.errors.email}
                helperText={formState.errors.email?.message as any}
              />
            </div>

            <div style={{ marginBottom: tokens.spacing.md }}>
              <AppTextField
                label="Password"
                type="password"
                {...register("password")}
                error={!!formState.errors.password}
                helperText={formState.errors.password?.message as any}
              />
            </div>

            <AppButton type="submit" fullWidth disabled={isLoading}>
              {isLoading ? "Signing in..." : "Sign in"}
            </AppButton>
          </form>
        </AppCard>
      </div>
    </div>
  );
}
