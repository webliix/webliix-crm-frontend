import { useEffect } from "react";
import { sessionService } from "@/shared/security/session.service";
import { authService } from "@/modules/auth/services/auth.service";
import { useAppDispatch } from "@/app/store/redux";
import { setToken, setUser, setLoading } from "@/modules/auth/store/authSlice";

export function useAuthBootstrap() {
  const dispatch = useAppDispatch();

  useEffect(() => {
    const bootstrap = async () => {
      try {
        const token = sessionService.getAccessToken();
        if (!token) return;

        dispatch(setLoading(true));
        dispatch(setToken(token));

        const res = await authService.me();
        const user = res?.data;
        if (user) dispatch(setUser(user));
      } catch (e) {
        // If token is invalid, keep the user logged out.
      } finally {
        dispatch(setLoading(false));
      }
    };

    bootstrap();
  }, [dispatch]);
}

export default useAuthBootstrap;
