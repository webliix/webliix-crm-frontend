import { useAppSelector } from "@/shared/hooks/redux";
import { selectUser } from "@/modules/auth/store/selectors";

export function usePermission() {
  const user = useAppSelector(selectUser);

  const hasPermission = (permission: string) => {
    return !!user?.permissions?.includes(permission);
  };

  return { hasPermission };
}
