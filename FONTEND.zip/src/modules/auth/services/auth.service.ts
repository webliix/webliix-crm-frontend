import { authApi } from "@/modules/auth/api/auth.api";
import { AuthControllerService } from "@/api/generated";
import { sessionService } from "@/shared/security/session.service";

export const authService = {
  login(payload: unknown) {
    return AuthControllerService.login1(payload as any);
  },

  me() {
    return authApi.me();
  },

  logout() {
    sessionService.clear();
  },
};
