import { createSlice } from "@reduxjs/toolkit";
import type { PayloadAction } from "@reduxjs/toolkit";
import type { CurrentUser } from "@/modules/auth/types/auth.types";

interface AuthState {
  accessToken: string | null;
  authenticated: boolean;
  user: CurrentUser | null;
  loading: boolean;
}

const initialState: AuthState = {
  accessToken: null,
  authenticated: false,
  user: null,
  loading: true,
};

const authSlice = createSlice({
  name: "auth",

  initialState,

  reducers: {
    setToken: (state, action: PayloadAction<string>) => {
      state.accessToken = action.payload;
      state.authenticated = true;
    },

    setUser: (state, action: PayloadAction<CurrentUser>) => {
      state.user = action.payload;
    },

    setLoading: (state, action: PayloadAction<boolean>) => {
      state.loading = action.payload;
    },

    logout: (state) => {
      state.accessToken = null;
      state.authenticated = false;
      state.user = null;
    },
  },
});

export const { setToken, logout, setUser, setLoading } = authSlice.actions;

export default authSlice.reducer;
