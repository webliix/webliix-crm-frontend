import { http } from "@/shared/services/http";

export const authApi = {
  login(data: unknown) {
    return http.post("/auth/login", data);
  },

  me() {
    return http.get("/auth/me");
  },
};
