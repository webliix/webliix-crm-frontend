export interface DashboardStats {
  totalLeads: number;
  totalClients: number;
  totalProjects: number;
  totalInvoices: number;
}
