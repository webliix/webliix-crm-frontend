import List from "@mui/material/List";
import ListItem from "@mui/material/ListItem";
import ListItemText from "@mui/material/ListItemText";
import { AppCard } from "@/shared/components/ui";

const activityItems = [
  "Lead Created",
  "Client Updated",
  "Project Assigned",
];

export function DashboardActivity() {
  return (
    <AppCard>
      <List>
        {activityItems.map((item) => (
          <ListItem key={item} disablePadding>
            <ListItemText primary={item} />
          </ListItem>
        ))}
      </List>
    </AppCard>
  );
}
