import { AppCard } from "@/shared/components/ui";
import Typography from "@mui/material/Typography";

interface Props {
  title: string;
  value: number;
}

export function StatCard({ title, value }: Props) {
  return (
    <AppCard>
      <Typography variant="subtitle2" color="text.secondary" gutterBottom>
        {title}
      </Typography>
      <Typography variant="h4">{value}</Typography>
    </AppCard>
  );
}
