import Box from "@mui/material/Box";
import { AppCard, EmptyState, LoadingScreen } from "@/shared/components/ui";
import { StatCard } from "@/modules/dashboard/components/StatCard";
import { useDashboard } from "@/modules/dashboard/hooks/useDashboard";

export function DashboardStats() {
  const { data, isLoading, isError } = useDashboard();

  if (isLoading) {
    return (
      <AppCard>
        <LoadingScreen />
      </AppCard>
    );
  }

  if (isError || !data) {
    return <EmptyState message="Unable to load dashboard" />;
  }

  return (
    <Box
      sx={{
        display: "grid",
        gridTemplateColumns: {
          xs: "1fr",
          md: "repeat(2, 1fr)",
          lg: "repeat(4, 1fr)",
        },
        gap: 2,
      }}
    >
      <StatCard title="Total Leads" value={data.totalLeads} />
      <StatCard title="Total Clients" value={data.totalClients} />
      <StatCard title="Total Projects" value={data.totalProjects} />
      <StatCard title="Total Invoices" value={data.totalInvoices} />
    </Box>
  );
}
