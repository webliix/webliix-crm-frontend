import Stack from "@mui/material/Stack";
import { AppButton } from "@/shared/components/ui";
import { ActionGuard } from "@/shared/components/rbac/ActionGuard";
import { permissions } from "@/shared/rbac/permissions";

export function DashboardQuickActions() {
  return (
    <Stack direction="row" spacing={2} flexWrap="wrap">
      <ActionGuard permission={permissions.leads.create}>
        <AppButton> Create Lead </AppButton>
      </ActionGuard>
      <ActionGuard permission={permissions.clients.create}>
        <AppButton> Create Client </AppButton>
      </ActionGuard>
      <ActionGuard permission={permissions.projects.create}>
        <AppButton> Create Project </AppButton>
      </ActionGuard>
      <AppButton> Create Invoice </AppButton>
    </Stack>
  );
}
