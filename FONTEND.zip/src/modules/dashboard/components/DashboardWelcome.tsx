import Typography from "@mui/material/Typography";
import { AppCard } from "@/shared/components/ui";
import { useAppSelector } from "@/shared/hooks/redux";
import { selectUser } from "@/modules/auth/store/selectors";

export function DashboardWelcome() {
  const user = useAppSelector(selectUser);

  return (
    <AppCard>
      <Typography variant="h6" gutterBottom>
        Welcome Back
      </Typography>
      <Typography variant="body1">
        {user?.firstName ? user.firstName : "User"}
      </Typography>
    </AppCard>
  );
}
