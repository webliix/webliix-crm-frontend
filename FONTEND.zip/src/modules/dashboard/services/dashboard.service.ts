import type { DashboardStats } from "@/modules/dashboard/types/dashboard.types";

export const dashboardService = {
  async getStats(): Promise<DashboardStats> {
    return {
      totalLeads: 120,
      totalClients: 45,
      totalProjects: 18,
      totalInvoices: 93,
    };
  },
};
