import { AppContainer, PageHeader } from "@/shared/components/ui";
import { DashboardActivity } from "@/modules/dashboard/components/DashboardActivity";
import { DashboardQuickActions } from "@/modules/dashboard/components/DashboardQuickActions";
import { DashboardStats } from "@/modules/dashboard/components/DashboardStats";
import { DashboardWelcome } from "@/modules/dashboard/components/DashboardWelcome";

export default function DashboardPage() {
  return (
    <AppContainer>
      <PageHeader title="Dashboard" />
      <DashboardWelcome />
      <DashboardStats />
      <DashboardQuickActions />
      <DashboardActivity />
    </AppContainer>
  );
}
