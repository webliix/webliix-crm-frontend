import { createTheme } from "@mui/material";
import { tokens } from "@/theme/tokens";

export const darkTheme = createTheme({
  palette: {
    mode: "dark",
    primary: {
      main: "#2563eb",
      contrastText: "#ffffff",
    },
    secondary: {
      main: "#94a3b8",
    },
    background: {
      default: "#0f172a",
      paper: "#1e293b",
    },
  },
  typography: {
    fontFamily: ["Inter", "Roboto", "sans-serif"].join(", "),
    h5: {
      fontWeight: 600,
    },
  },
  shape: {
    borderRadius: tokens.borderRadius.md,
  },
  components: {
    MuiButton: {
      defaultProps: {
        disableElevation: true,
        variant: "contained",
      },
    },
    MuiTextField: {
      defaultProps: {
        size: "small",
        fullWidth: true,
      },
    },
    MuiCard: {
      styleOverrides: {
        root: {
          borderRadius: tokens.borderRadius.sm,
        },
      },
    },
  },
});
