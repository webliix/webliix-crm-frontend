import { OpenAPI } from "@/api/generated";
import { env } from "@/config/env";

OpenAPI.BASE = env.apiBaseUrl;
