import { errorHandler } from "./errorHandler";
import type { AppDispatch } from "@/app/store";
import { logout } from "@/modules/auth/store/authSlice";
import { tokenService } from "@/modules/auth/services/token.service";

export function handleUnauthorized(dispatch: AppDispatch, navigate?: (path: string) => void): void {
  // Clear token
  tokenService.clear();

  // Dispatch logout action
  dispatch(logout());

  // Navigate to login if navigate function provided
  if (navigate) {
    navigate("/login");
  }

  // Log error
  errorHandler.handle("Session expired. Please log in again.");
}
