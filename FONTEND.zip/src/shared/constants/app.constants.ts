export const APP_NAME = "Webliix CRM";
