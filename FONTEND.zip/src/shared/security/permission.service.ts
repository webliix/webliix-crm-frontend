import type { CurrentUser } from "@/modules/auth/types/auth.types";

export const permissionService = {
  can(user: CurrentUser | null | undefined, permission: string): boolean {
    return Boolean(user?.permissions?.includes(permission));
  },

  hasRole(user: CurrentUser | null | undefined, role: string): boolean {
    return Boolean(user?.roles?.includes(role));
  },
};
