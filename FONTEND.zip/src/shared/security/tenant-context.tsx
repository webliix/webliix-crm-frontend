import { createContext, useContext, useMemo, useState, type ReactNode } from "react";

export interface TenantInfo {
  tenantId?: string;
  tenantName?: string;
  plan?: string;
  subscription?: string;
}

interface TenantContextValue extends TenantInfo {
  setTenantInfo: (info: TenantInfo) => void;
  clearTenant: () => void;
}

const TenantContext = createContext<TenantContextValue | undefined>(undefined);

interface Props {
  children: ReactNode;
}

export function TenantProvider({ children }: Props) {
  const [tenantInfo, setTenantInfo] = useState<TenantInfo>({});

  const value = useMemo(
    () => ({
      ...tenantInfo,
      setTenantInfo: (info: TenantInfo) => setTenantInfo((current) => ({ ...current, ...info })),
      clearTenant: () => setTenantInfo({}),
    }),
    [tenantInfo],
  );

  return <TenantContext.Provider value={value}>{children}</TenantContext.Provider>;
}

export function useTenantContext(): TenantContextValue {
  const context = useContext(TenantContext);
  if (!context) {
    throw new Error("useTenantContext must be used within TenantProvider");
  }
  return context;
}
