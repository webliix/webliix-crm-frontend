import { handleUnauthorized } from "@/shared/errors/handleUnauthorized";
import type { AppDispatch } from "@/app/store";
import { logout } from "@/modules/auth/store/authSlice";

const ACCESS_TOKEN_KEY = "crm_access_token";
const REFRESH_TOKEN_KEY = "crm_refresh_token";
const EXPIRY_KEY = "crm_session_expiry";

const decodeJwtPayload = (token: string): Record<string, any> | undefined => {
  try {
    const [, payload] = token.split(".");
    if (!payload) {
      return undefined;
    }
    const base64 = payload.replace(/-/g, "+").replace(/_/g, "/");
    const decoded = atob(base64.padEnd(base64.length + (4 - (base64.length % 4)) % 4, "="));
    return JSON.parse(decoded);
  } catch {
    return undefined;
  }
};

const getExpiryFromToken = (token: string): Date | undefined => {
  const payload = decodeJwtPayload(token);
  if (!payload || typeof payload.exp !== "number") {
    return undefined;
  }
  return new Date(payload.exp * 1000);
};

export const sessionService = {
  getAccessToken(): string | null {
    return localStorage.getItem(ACCESS_TOKEN_KEY);
  },

  getRefreshToken(): string | null {
    return localStorage.getItem(REFRESH_TOKEN_KEY);
  },

  setTokens(accessToken: string, refreshToken?: string): void {
    localStorage.setItem(ACCESS_TOKEN_KEY, accessToken);
    if (refreshToken) {
      localStorage.setItem(REFRESH_TOKEN_KEY, refreshToken);
    }

    const expiry = getExpiryFromToken(accessToken);
    if (expiry) {
      localStorage.setItem(EXPIRY_KEY, expiry.toISOString());
    }
  },

  clear(): void {
    localStorage.removeItem(ACCESS_TOKEN_KEY);
    localStorage.removeItem(REFRESH_TOKEN_KEY);
    localStorage.removeItem(EXPIRY_KEY);
  },

  getExpiry(): Date | null {
    const raw = localStorage.getItem(EXPIRY_KEY);
    if (!raw) {
      return null;
    }
    const date = new Date(raw);
    return Number.isNaN(date.getTime()) ? null : date;
  },

  isExpired(): boolean {
    const expiry = this.getExpiry();
    if (!expiry) {
      return false;
    }
    return expiry.getTime() <= Date.now();
  },

  async refresh(): Promise<string> {
    const refreshToken = this.getRefreshToken();
    if (!refreshToken) {
      return Promise.reject(new Error("Refresh token is not available."));
    }

    // Refresh token endpoint is not currently declared in the OpenAPI spec.
    // This method is intentionally prepared for the backend refresh flow once the API is available.
    return Promise.reject(new Error("Refresh endpoint is not configured."));
  },

  markSessionExpired(dispatch: AppDispatch) {
    this.clear();
    dispatch(logout());
    handleUnauthorized(dispatch);
  },
};
