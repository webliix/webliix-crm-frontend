import axios from "axios";
import { env } from "@/config/env";
import { sessionService } from "@/shared/security/session.service";
import { mapApiError } from "@/shared/errors/mapApiError";
import { errorHandler } from "@/shared/errors/errorHandler";

export const http = axios.create({
  baseURL: env.apiBaseUrl,
  timeout: 30000,
  headers: {
    "Content-Type": "application/json",
  },
});

// Request interceptor: add token to headers
http.interceptors.request.use((config) => {
  try {
    const token = sessionService.getAccessToken();

    if (token) {
      (config.headers as any) = config.headers ?? {};
      (config.headers as any).Authorization = `Bearer ${token}`;
    }
  } catch (e) {
    // ignore
  }

  return config;
});

// Response interceptor: handle errors globally
http.interceptors.response.use(
  (response) => response,
  async (error) => {
    if (error.response?.status === 401) {
      try {
        await sessionService.refresh();
      } catch {
        sessionService.clear();
      }
    }

    const appError = mapApiError(error);
    errorHandler.handle(appError);

    // Return rejected promise so calling code can still handle if needed
    return Promise.reject(appError);
  },
);
