import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import type { ReactNode } from "react";

interface Props {
  children: ReactNode;
}

export function AppCard({ children }: Props) {
  return (
    <Card>
      <CardContent>{children}</CardContent>
    </Card>
  );
}
