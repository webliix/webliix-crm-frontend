import CircularProgress from "@mui/material/CircularProgress";

export function LoadingScreen() {
  return <CircularProgress />;
}
