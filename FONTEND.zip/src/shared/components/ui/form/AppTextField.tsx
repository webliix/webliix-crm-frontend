import TextField from "@mui/material/TextField";

export function AppTextField(props: any) {
  return (
    <TextField
      fullWidth
      size="small"
      margin="normal"
      {...props}
    />
  );
}
