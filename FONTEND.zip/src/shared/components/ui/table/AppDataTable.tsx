import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";
import TablePagination from "@mui/material/TablePagination";
import CircularProgress from "@mui/material/CircularProgress";
import Box from "@mui/material/Box";

import type { ReactNode } from "react";

export interface DataTableColumn<RowType> {
  field: keyof RowType;
  headerName: string;
  flex?: number;
  render?: (value: any, row: RowType) => ReactNode;
}

interface AppDataTableProps<RowType> {
  rows: RowType[];
  columns: DataTableColumn<RowType>[];
  loading?: boolean;
  page?: number;
  pageSize?: number;
  totalRows?: number;
  pageSizeOptions?: number[];
  onPageChange?: (page: number) => void;
  onPageSizeChange?: (size: number) => void;
}

export function AppDataTable<RowType extends Record<string, any>>({
  rows,
  columns,
  loading = false,
  page = 0,
  pageSize = 20,
  totalRows = 0,
  pageSizeOptions = [10, 20, 50, 100],
  onPageChange,
  onPageSizeChange,
}: AppDataTableProps<RowType>) {
  const handleChangePage = (_: unknown, newPage: number) => {
    onPageChange?.(newPage);
  };

  const handleChangeRowsPerPage = (event: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const newSize = Number(event.target.value);
    onPageSizeChange?.(newSize);
    onPageChange?.(0);
  };

  return (
    <TableContainer component={Paper}>
      <Table>
        <TableHead>
          <TableRow>
            {columns.map((column) => (
              <TableCell
                key={String(column.field)}
                sx={{ width: column.flex ? `${column.flex * 100}px` : undefined }}
              >
                {column.headerName}
              </TableCell>
            ))}
          </TableRow>
        </TableHead>
        <TableBody>
          {loading ? (
            <TableRow>
              <TableCell colSpan={columns.length}>
                <Box sx={{ display: 'flex', justifyContent: 'center', py: 4 }}>
                  <CircularProgress />
                </Box>
              </TableCell>
            </TableRow>
          ) : rows.length === 0 ? (
            <TableRow>
              <TableCell colSpan={columns.length}>
                <Box sx={{ py: 4, textAlign: 'center' }}>No data</Box>
              </TableCell>
            </TableRow>
          ) : (
            rows.map((row, rowIndex) => (
              <TableRow key={String((row as any).id ?? rowIndex)}>
                {columns.map((column) => (
                  <TableCell key={`${String(column.field)}-${rowIndex}`}>
                    {column.render ? column.render(row[column.field], row) : String(row[column.field] ?? "")}
                  </TableCell>
                ))}
              </TableRow>
            ))
          )}
        </TableBody>
      </Table>
      <TablePagination
        component="div"
        count={totalRows}
        page={page}
        onPageChange={handleChangePage}
        rowsPerPage={pageSize}
        onRowsPerPageChange={handleChangeRowsPerPage}
        rowsPerPageOptions={pageSizeOptions}
      />
    </TableContainer>
  );
}
