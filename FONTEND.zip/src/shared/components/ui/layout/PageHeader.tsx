import Typography from "@mui/material/Typography";

interface Props {
  title: string;
}

export function PageHeader({ title }: Props) {
  return (
    <Typography variant="h5" fontWeight={600}>
      {title}
    </Typography>
  );
}
