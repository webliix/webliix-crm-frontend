import Container from "@mui/material/Container";
import type { ReactNode } from "react";

interface Props {
  children: ReactNode;
}

export function AppContainer({ children }: Props) {
  return <Container maxWidth="xl">{children}</Container>;
}
