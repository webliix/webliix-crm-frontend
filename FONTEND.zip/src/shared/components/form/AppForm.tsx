import { Box, Button } from "@mui/material";
import { FormProvider, useForm } from "react-hook-form";
import type { ReactNode } from "react";

interface Props {
  children: ReactNode;
  defaultValues?: Record<string, any>;
  onSubmit: (values: any) => Promise<void> | void;
  submitLabel?: string;
  loading?: boolean;
}

export function AppForm({ children, defaultValues = {}, onSubmit, submitLabel = "Save", loading = false }: Props) {
  const methods = useForm({ defaultValues });

  return (
    <FormProvider {...methods}>
      <form
        onSubmit={methods.handleSubmit(async (values) => {
          await onSubmit(values);
        })}
      >
        <Box sx={{ display: "grid", gap: 2 }}>{children}</Box>

        <Box sx={{ display: "flex", justifyContent: "flex-end", mt: 2 }}>
          <Button type="submit" variant="contained" disabled={loading}>
            {submitLabel}
          </Button>
        </Box>
      </form>
    </FormProvider>
  );
}
