import Typography from "@mui/material/Typography";
import { AppCard } from "@/shared/components/ui";
import type { ReactNode } from "react";

interface Props {
  title: string;
  children?: ReactNode;
}

export function FormSection({ title, children }: Props) {
  return (
    <AppCard>
      <Typography variant="subtitle1" sx={{ mb: 1 }}>
        {title}
      </Typography>
      {children}
    </AppCard>
  );
}
