import { useEffect, useState, type ReactNode } from "react";
import Button from "@mui/material/Button";
import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import DialogContentText from "@mui/material/DialogContentText";
import DialogTitle from "@mui/material/DialogTitle";
import { useAppDispatch } from "@/app/store/redux";
import { errorHandler } from "@/shared/errors/errorHandler";
import { sessionService } from "@/shared/security/session.service";
import { handleUnauthorized } from "@/shared/errors/handleUnauthorized";

interface Props {
  children: ReactNode;
}

export function SessionProvider({ children }: Props) {
  const dispatch = useAppDispatch();
  const [expired, setExpired] = useState(false);

  useEffect(() => {
    const listener = (errorContext: { code?: number }) => {
      if (errorContext.code === 401) {
        handleUnauthorized(dispatch);
        setExpired(true);
      }
    };

    const unsubscribe = errorHandler.subscribe(listener);
    return unsubscribe;
  }, [dispatch]);

  useEffect(() => {
    if (sessionService.isExpired()) {
      handleUnauthorized(dispatch);
      setExpired(true);
    }

    const interval = window.setInterval(() => {
      if (sessionService.isExpired()) {
        handleUnauthorized(dispatch);
        setExpired(true);
      }
    }, 30_000);

    return () => window.clearInterval(interval);
  }, [dispatch]);

  const handleLoginRedirect = () => {
    setExpired(false);
    window.location.assign("/login");
  };

  return (
    <>
      {children}
      <Dialog open={expired} onClose={handleLoginRedirect} aria-labelledby="session-expired-title">
        <DialogTitle id="session-expired-title">Session expired</DialogTitle>
        <DialogContent>
          <DialogContentText>
            Your session has ended. Please sign in again to continue working.
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleLoginRedirect} variant="contained" color="primary">
            Go to Login
          </Button>
        </DialogActions>
      </Dialog>
    </>
  );
}
