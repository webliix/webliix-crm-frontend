import { Navigate } from "react-router-dom";
import type { ReactNode } from "react";
import { useAppSelector } from "@/app/store/redux";
import { LoadingScreen } from "@/shared/components/ui";
import { selectAuth } from "@/modules/auth/store/selectors";

interface Props {
  children: ReactNode;
}

export function ProtectedRoute({ children }: Props) {
  const { accessToken, loading } = useAppSelector(selectAuth);

  if (loading) {
    return <LoadingScreen />;
  }

  if (!accessToken) {
    return <Navigate to="/login" replace />;
  }

  return <>{children}</>;
}
