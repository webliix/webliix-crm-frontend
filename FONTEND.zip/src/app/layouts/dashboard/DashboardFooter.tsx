export function DashboardFooter() {
  return <div>© Webliix CRM</div>;
}
