import Box from "@mui/material/Box";
import IconButton from "@mui/material/IconButton";
import Avatar from "@mui/material/Avatar";
import Menu from "@mui/material/Menu";
import MenuItem from "@mui/material/MenuItem";
import Tooltip from "@mui/material/Tooltip";
import { layout } from "@/shared/constants/layout";
import { useState } from "react";
import { useAppSelector } from "@/app/store/redux";
import { selectUser, selectAuthenticated } from "@/modules/auth/store/selectors";
import { useLogout } from "@/modules/auth/hooks/useLogout";
import { notificationService } from "@/shared/notifications/notification.service";
import { messages } from "@/shared/constants/messages";

export function DashboardHeader() {
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const open = Boolean(anchorEl);
  const user = useAppSelector(selectUser);
  const authenticated = useAppSelector(selectAuthenticated);
  const logout = useLogout();

  const handleOpen = (e: React.MouseEvent<HTMLElement>) => setAnchorEl(e.currentTarget);
  const handleClose = () => setAnchorEl(null);

  const handleLogout = () => {
    handleClose();
    logout();
    notificationService.success(messages.logoutSuccess);
  };

  return (
    <Box
      sx={{
        height: layout.headerHeight,
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        px: 2,
      }}
    >
      <Box>Header</Box>

      <Box>
        {authenticated && (
          <Tooltip title={user ? `${user.firstName} ${user.lastName}` : "User"}>
            <IconButton onClick={handleOpen} size="small">
              <Avatar>{user ? (user.firstName || "U").charAt(0) : "U"}</Avatar>
            </IconButton>
          </Tooltip>
        )}

        <Menu anchorEl={anchorEl} open={open} onClose={handleClose}>
          <MenuItem onClick={handleLogout}>{messages.logout}</MenuItem>
        </Menu>
      </Box>
    </Box>
  );
}
