import Box from "@mui/material/Box";
import type { ReactNode } from "react";
import { DashboardHeader } from "./DashboardHeader";
import { DashboardSidebar } from "./DashboardSidebar";
import { DashboardFooter } from "./DashboardFooter";

interface Props {
  children: ReactNode;
}

export function DashboardLayout({ children }: Props) {
  return (
    <Box sx={{ display: "flex" }}>
      <DashboardSidebar />

      <Box sx={{ flex: 1 }}>
        <DashboardHeader />

        {children}

        <DashboardFooter />
      </Box>
    </Box>
  );
}
