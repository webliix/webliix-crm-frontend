import Box from "@mui/material/Box";
import Divider from "@mui/material/Divider";
import List from "@mui/material/List";
import Typography from "@mui/material/Typography";
import { layout } from "@/shared/constants/layout";
import { useNavigation } from "@/app/navigation/hooks/useNavigation";
import { SidebarMenuItem } from "@/app/navigation/components/SidebarMenuItem";

export function DashboardSidebar() {
  const navigationItems = useNavigation();

  return (
    <Box
      sx={{
        width: layout.sidebarWidth,
        minHeight: "100vh",
        bgcolor: "background.paper",
        borderRight: 1,
        borderColor: "divider",
      }}
    >
      <Box sx={{ px: 3, py: 2 }}>
        <Typography variant="h6">Navigation</Typography>
      </Box>
      <Divider />
      <List disablePadding>
        {navigationItems.map((item) => (
          <SidebarMenuItem key={item.path} item={item} />
        ))}

        {navigationItems.length === 0 ? (
          <Box sx={{ px: 3, py: 2, color: "text.secondary" }}>
            No accessible sections
          </Box>
        ) : null}
      </List>
    </Box>
  );
}
