import ListItemButton from "@mui/material/ListItemButton";
import ListItemIcon from "@mui/material/ListItemIcon";
import ListItemText from "@mui/material/ListItemText";
import type { NavigationItem } from "@/app/navigation/types";
import { NavLink } from "react-router-dom";

interface Props {
  item: NavigationItem;
}

export function SidebarMenuItem({ item }: Props) {
  return (
    <ListItemButton
      component={NavLink}
      to={item.path}
      end={item.path === "/dashboard"}
      sx={{
        px: 3,
        py: 1.5,
        color: "text.primary",
        "&.active": {
          bgcolor: "action.selected",
          color: "primary.main",
        },
      }}
    >
      {item.icon ? (
        <ListItemIcon sx={{ minWidth: 40 }}>{item.icon}</ListItemIcon>
      ) : null}
      <ListItemText primary={item.label} />
    </ListItemButton>
  );
}
