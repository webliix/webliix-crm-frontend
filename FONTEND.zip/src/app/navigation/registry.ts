import type { CurrentUser } from "@/modules/auth/types/auth.types";
import type { NavigationItem } from "./types";
import { menuItems } from "./menu";

export function getVisibleNavigationItems(user: CurrentUser | null | undefined): NavigationItem[] {
  if (!user) {
    return menuItems.filter((item) => !item.permission);
  }

  return menuItems.filter(
    (item) => !item.permission || user.permissions.includes(item.permission),
  );
}
