import type { ReactNode } from "react";
import { ReduxProvider } from "./ReduxProvider";
import { QueryProvider } from "./QueryProvider";
import { ThemeProvider } from "./ThemeProvider";
import { NotificationProvider } from "@/shared/notifications";
import { OpenAPI } from "@/api/generated/core/OpenAPI";
import { AuthProvider, TenantProvider, sessionService } from "@/shared/security";
import { SessionProvider } from "@/shared/providers/SessionProvider";

interface Props {
  children: ReactNode;
}

export function AppProviders({ children }: Props) {
  // Ensure generated OpenAPI client picks up the current access token from storage
  OpenAPI.TOKEN = async (_options) => {
    const t = await sessionService.getAccessToken();
    return t ?? "";
  };

  return (
    <ReduxProvider>
      <ThemeProvider>
        <QueryProvider>
          <NotificationProvider>
            <AuthProvider>
              <TenantProvider>
                <SessionProvider>{children}</SessionProvider>
              </TenantProvider>
            </AuthProvider>
          </NotificationProvider>
        </QueryProvider>
      </ThemeProvider>
    </ReduxProvider>
  );
}
